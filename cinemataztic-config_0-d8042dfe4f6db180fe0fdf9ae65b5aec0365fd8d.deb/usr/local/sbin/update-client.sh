#!/bin/bash 

# Extract arguments
while getopts r: option
do
case "${option}"
in
r) REBOOT=${OPTARG};;
esac
done

if [ -e /tmp/newsources/sources.list.d ]
then
  cp /tmp/newsources/sources.list.d/* /etc/apt/sources.list.d/
  sudo apt-get update
  echo 'ran apt-get update'
  sudo apt-get dist-upgrade -y
  echo 'ran apt-get dist-upgrade'
  sudo systemctl restart cinemataztic-player
  openbox --reconfigure
  date +%s >> $HOME/cinemataztic-last-sw-update.txt

  if [ -n "$REBOOT" ] && [ "$REBOOT" = 'true' ]
  then
    sudo /sbin/reboot
  fi
fi

echo "ran update-client.sh"